names_to_remove = ["Guest"]
database_path = "players.sqlite"