from config import *
import sqlite3
import json

deleted_accounts = 0
names_to_remove = names_to_remove
database_path = database_path

db = sqlite3.connect(database_path)
cr = db.cursor()

cr.execute(f"SELECT * FROM main")
data = cr.fetchall()

for player in data:
	player_data = json.loads(player[2])['DATA']
	if player_data['Name'] in names_to_remove:
		cr.execute(f"DELETE FROM main WHERE auth = '{player[1]}'")
		deleted_accounts += 1
db.commit()
print(deleted_accounts, "accounts deleted.")